/*• Declare um vetor com contendo os elementos 10, 5, 8, 2 e 8. Em seguida,
mostre os elementos contidos no array*/
import java.util.*;
public class vetor {
    public static void main(String[] args){
        int vet[] = {10,5,8,2,8};
        for(int i=0;i<vet.length;i++){
            System.out.println(vet[i]);
        }
    }
}
